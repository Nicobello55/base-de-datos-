let mysql=require("mysql2");

let conexión = mysql.createConnection({

  host: '127.0.0.1',
  user: 'root',
  password: 'umma',
  database: 'base'



})

conexión.connect(function(err){

  if(err){
    throw err;
  }else{

    console.log("conexion exitosa")
  }

})

const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: false }));

// Configura la conexión a la base de datos
const db = mysql.createConnection({
    host: '127.0.0.1',
    user: 'root',
    password: 'umma',
    database: 'base'
  });
 
  db.connect((err) => {
    if (err) {
      console.error('Error al conectar a la base de datos: ' + err.message);
    } else {
      console.log('Conexión a la base de datos establecida.');
    }
  });
app.use(express.static('public'));
app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // Aquí puedes agregar tu lógica para verificar las credenciales en la base de datos.
  // Puedes reemplazar esta parte con la lógica real de autenticación.

  // Ejemplo de respuesta para la demostración:
  // Realiza la consulta a la base de datos para verificar las credenciales

  const query = 'SELECT * FROM datos WHERE username = ? AND password = ?';
  db.query(query, [username, password], (err, results) => {
    if (err) {
      console.error('Error en la consulta: ' + err.message);
      res.send('Error en la consulta.');
    } else {
      if (results.length > 0) {
        // Redirige al usuario a la página principal
        res.redirect('/principal.html');
      } else {
        res.send('Credenciales incorrectas');
      }
    }
  });
}); 
// Configura la carpeta "public" para servir archivos estáticos
app.use(express.static('public'));

// Esta ruta redirigirá a "index.html" en la carpeta "public"
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

app.listen(port, () => {
    console.log(`Servidor Node.js corriendo en el puerto ${port}`);
  });
  
 
    
    
